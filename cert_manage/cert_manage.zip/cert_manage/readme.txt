python3 -m venv /opt/py3
source /opt/py3/bin/activate
cd /opt/
cd /opt/cert_manage
pip install -r requirements/requirements.txt
cd /opt/cert_manage
python run_server.py





#mac版
python3 -m venv opt/py3
source /Users/xiingxiing/Desktop/opt/py3/bin/activate
cd /Users/xiingxiing/Desktop/opt/cert_manage
pip install -r requirements/requirements.txt
cd /Users/xiingxiing/Desktop/opt/cert_manage
python run_server.py