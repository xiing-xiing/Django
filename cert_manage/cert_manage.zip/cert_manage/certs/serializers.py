
from rest_framework import serializers
from rest_framework_bulk import BulkListSerializer

from users.mixins import BulkSerializerMixin
from certs.models import Certs
from users.serializers import UserSerializer


class CertSerializer(BulkSerializerMixin, serializers.ModelSerializer):
    """
    证书的数据结构
    """

    class Meta:
        model = Certs
        list_serializer_class = BulkListSerializer
        fields = '__all__'
        validators = []

    def get_field_names(self, declared_fields, info):
        fields = super().get_field_names(declared_fields, info)
        fields.extend([
            'get_method'
        ])
        return fields
