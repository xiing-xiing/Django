from users.mixins import IDInFilterMixin
from rest_framework_bulk import BulkModelViewSet
from rest_framework.pagination import LimitOffsetPagination

from users.permissions import IsSuperUser
from certs import serializers
from certs.models import Certs


class CertViewSet(IDInFilterMixin, BulkModelViewSet):
    """
    证书操作接口
    """
    filter_fields = ('name', 'domain', 'orther_domain', 'organization_name', 'cert_type', 'comment')
    search_fields = filter_fields
    ordering_fields = ('domain',)
    queryset = Certs.objects.all()
    serializer_class = serializers.CertSerializer
    pagination_class = LimitOffsetPagination
    permission_classes = (IsSuperUser,)
