# !/usr/bin/python3
#coding=utf-8

from datetime import datetime
from cert_manage.celery import app
from cert_manage.utils import certs_messages_remaind_email
from certs.models import Certs
from certs.utils import load_certificate
import requests, json
import time
import smtplib
from email.mime.text import MIMEText
from email.header import Header


wx_url = ""  #写企业微信的wehook

def send_msg(content):
    data = json.dumps({"msgtype": "text", "text": {"content": content, "mentioned_list":[""]}})
    r = requests.post(wx_url, data, auth=('Content-Type', 'application/json'))
    print(r.json)


@app.task
def refresh_certs_messages_to_db(cert_obj_id=None):

    certs = Certs.objects.filter(id=cert_obj_id) if cert_obj_id else Certs.objects.all()

    for cert in certs:
        Certs._meta.auto_created = True
        try:
            if not cert.method: cert.method = 0
            if cert.method == 0:
                cert_info = load_certificate(cert.method, cert.domain_url)
            else:
                cert_info = load_certificate(cert.method, cert.crt_file)

            for k, v in cert_info.items():
                setattr(cert, k, v)
                if k.startswith('remain_days'):
                    if int(v) <= 90:
                        base_message = '还有Days天到期'
                        if int(cert_info.get('remain_days')) == 0:
                            message = '已到期'
                        elif int(cert_info.get('remain_days')) < 0:
                            message = '已过期'
                        elif int(cert_info.get('remain_days')) in [90, 60, 45, 30, 15] or int(
                                cert_info.get('remain_days')) <= 14:
                            message = base_message.replace('Days', str(cert_info.get('remain_days')))
                        else:
                            message = None

                        if message:
                            if len(cert_info.get('orther_domain')) > 0:
                                orther_domain = [domain[1] for domain in cert_info.get('orther_domain')]
                            else:
                                orther_domain = cert_info.get('orther_domain')
                            subject = ('重要通知：%(domain)s证书到期提醒(%(time)s)') % {'domain': cert_info.get('domain'),
                                                                              'time': datetime.now().strftime(
                                                                                  '%Y-%m-%d %H:%M:%S')}
                            recipient_list = [user.email for user in cert.users.all()]
                            message = ("""大家好,%(domain)s证书%(message)s，避免影响业务的正常运行请及时更新。有效期至: %(notafter)s""") % {
                                'domain': cert_info.get('domain'),
                                'message': message,
                                'notafter': cert_info.get('notafter'),
                            }

                            print(subject)
                            print(message)
                            print(recipient_list)

                            send_message1 = message
                            send_msg(send_message1)             #发送企业微信告警


                            # 第三方 SMTP 服务
                            mail_host = ""  # 设置服务器
                            mail_user = ""  # 用户名
                            mail_pass = ""  # 口令
                            sender = ''
                            receivers = ['']  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱

                            message1 = MIMEText(message, 'plain', 'utf-8')
                            message1['From'] = Header("证书告警", 'utf-8')
                            message1['To'] = Header("证书管理员", 'utf-8')
                            message1['Subject'] = Header(subject, 'utf-8')

                            try:
                                smtpObj = smtplib.SMTP()
                                smtpObj.connect(mail_host, 25)  # 25 为 SMTP 端口号
                                smtpObj.login(mail_user, mail_pass)
                                smtpObj.sendmail(sender, recipient_list, message1.as_string())
                                print("邮件发送成功")
                            except smtplib.SMTPException:
                                print("Error: 无法发送邮件")
                        #certs_messages_remaind_email(cert, cert_info)
            cert.save()

        except  Exception as e:
            print(e)
        finally:
            Certs._meta.auto_created = False
    return 0
